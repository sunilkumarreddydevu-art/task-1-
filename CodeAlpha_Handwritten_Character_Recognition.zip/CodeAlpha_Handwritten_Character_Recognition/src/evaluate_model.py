
from tensorflow.keras import datasets
from tensorflow.keras.models import load_model

(train_images, train_labels), (test_images, test_labels) = datasets.mnist.load_data()

test_images = test_images/255.0
test_images = test_images.reshape((10000,28,28,1))

model = load_model("../models/cnn_model.h5")

loss,acc = model.evaluate(test_images,test_labels)

print("Test Accuracy:",acc)
