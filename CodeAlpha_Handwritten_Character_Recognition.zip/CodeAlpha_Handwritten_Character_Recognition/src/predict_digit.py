
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import load_model

(_, _),(test_images,test_labels)=mnist.load_data()

test_images=test_images/255.0
test_images=test_images.reshape((10000,28,28,1))

model=load_model("../models/cnn_model.h5")

index=5
image=test_images[index]

prediction=model.predict(image.reshape(1,28,28,1))

print("Predicted Digit:",np.argmax(prediction))
print("Actual Digit:",test_labels[index])

plt.imshow(image.reshape(28,28),cmap="gray")
plt.show()
