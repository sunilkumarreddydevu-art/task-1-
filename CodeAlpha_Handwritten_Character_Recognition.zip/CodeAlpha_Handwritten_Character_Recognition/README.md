
# Handwritten Character Recognition - CodeAlpha Internship

This project uses a Convolutional Neural Network (CNN) to recognize handwritten digits.

Dataset:
MNIST dataset

Model:
Convolutional Neural Network (CNN)

Accuracy:
~98%

Run Training:
python src/train_model.py

Evaluate Model:
python src/evaluate_model.py

Predict Digit:
python src/predict_digit.py
