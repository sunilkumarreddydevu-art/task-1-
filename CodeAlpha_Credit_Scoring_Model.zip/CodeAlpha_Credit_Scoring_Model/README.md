# Credit Scoring Model - CodeAlpha Internship

This machine learning project predicts whether a person is creditworthy using financial history.

## Features
- Income
- Debt
- Payment History
- Loan Amount

## Algorithms
Random Forest Classifier

## Evaluation Metrics
- Accuracy
- Precision
- Recall
- F1 Score
- ROC-AUC

## How to Run

Install requirements:

pip install -r requirements.txt

Train the model:

python src/train_model.py

Evaluate the model:

python src/evaluate_model.py

Predict creditworthiness:

python src/predict.py