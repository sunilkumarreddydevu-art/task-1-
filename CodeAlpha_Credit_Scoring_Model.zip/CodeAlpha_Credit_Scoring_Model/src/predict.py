import joblib
import numpy as np

model = joblib.load("../models/credit_model.pkl")

income = float(input("Enter income: "))
debt = float(input("Enter debt: "))
payment_history = int(input("Payment history (1=good,0=bad): "))
loan_amount = float(input("Loan amount: "))

data = np.array([[income, debt, payment_history, loan_amount]])

prediction = model.predict(data)

if prediction[0] == 1:
    print("Credit Approved")
else:
    print("Credit Rejected")