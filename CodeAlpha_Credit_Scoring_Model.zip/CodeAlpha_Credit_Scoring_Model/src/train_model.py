import joblib
from sklearn.ensemble import RandomForestClassifier
from data_preprocessing import preprocess_data

X_train, X_test, y_train, y_test = preprocess_data("../data/credit_data.csv")

model = RandomForestClassifier(
    n_estimators=200,
    max_depth=8,
    random_state=42
)

model.fit(X_train, y_train)

joblib.dump(model, "../models/credit_model.pkl")

print("Model trained and saved successfully.")