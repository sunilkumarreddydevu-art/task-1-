
# Disease Prediction from Medical Data

Machine Learning project that predicts diseases using patient medical data.

Dataset:
Breast Cancer dataset (UCI ML Repository via sklearn)

Algorithms:
- Logistic Regression
- Support Vector Machine (SVM)
- Random Forest

Evaluation Metrics:
- Accuracy
- Precision
- Recall
- F1 Score

Run Training:
python src/train_models.py

Evaluate Models:
python src/evaluate_models.py

Predict Disease:
python src/predict_disease.py
