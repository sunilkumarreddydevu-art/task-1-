
# Evaluate Disease Prediction Models

import joblib
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

data = load_breast_cancer()

X = data.data
y = data.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

models = ["logistic_regression","svm","random_forest"]

for name in models:
    model = joblib.load(f"../models/{name}.pkl")
    preds = model.predict(X_test)

    print("\nModel:", name)
    print("Accuracy:", accuracy_score(y_test,preds))
    print("Precision:", precision_score(y_test,preds))
    print("Recall:", recall_score(y_test,preds))
    print("F1 Score:", f1_score(y_test,preds))
