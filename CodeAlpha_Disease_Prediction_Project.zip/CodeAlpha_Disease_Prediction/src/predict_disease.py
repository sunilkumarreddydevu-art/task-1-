
# Predict Disease from Patient Data

import numpy as np
import joblib
from sklearn.datasets import load_breast_cancer

model = joblib.load("../models/random_forest.pkl")
scaler = joblib.load("../models/scaler.pkl")

data = load_breast_cancer()
feature_names = data.feature_names

print("Enter patient medical data")

values = []
for f in feature_names:
    val = float(input(f"{f}: "))
    values.append(val)

values = np.array(values).reshape(1,-1)
values = scaler.transform(values)

prediction = model.predict(values)

if prediction[0] == 1:
    print("Prediction: Disease detected")
else:
    print("Prediction: No disease detected")
