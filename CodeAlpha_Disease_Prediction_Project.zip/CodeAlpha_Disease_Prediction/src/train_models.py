
# Train Disease Prediction Models

import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load dataset (UCI Breast Cancer Dataset via sklearn)
data = load_breast_cancer()

X = pd.DataFrame(data.data, columns=data.feature_names)
y = pd.Series(data.target)

# Train test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Feature scaling
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Models
models = {
    "logistic_regression": LogisticRegression(max_iter=500),
    "svm": SVC(probability=True),
    "random_forest": RandomForestClassifier(n_estimators=200)
}

# Train and save models
for name, model in models.items():
    model.fit(X_train, y_train)
    joblib.dump(model, f"../models/{name}.pkl")
    print(f"{name} model trained and saved")

joblib.dump(scaler, "../models/scaler.pkl")
